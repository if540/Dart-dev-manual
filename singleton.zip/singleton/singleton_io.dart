class Singleton {
  static Singleton? _instance;

  Singleton._internal() {
    _instance = this;
  }
  
  factory Singleton() {
    print('IO Singleton');
    return _instance ?? Singleton._internal();
  }
}
