import 'package:gogoapp/singleton/ISingleton.dart';

class Singleton extends ISingleton {
  static Singleton? _instance;

  Singleton._internal() {
    _instance = this;
  }
  
  factory Singleton() {
    return throw UnsupportedError('None Singleton');
  }
}
